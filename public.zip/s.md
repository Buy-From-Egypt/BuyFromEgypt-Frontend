# Posts
postId 
title
content
cloudFolder
user:{
    id
    name
    profileImage
}
rate 
comments_count
createdAt

# new request return
name 
profileImage
followers_count
industry
following_count
posts_count



'use client';

import Image from "next/image";
import React, { useEffect, useState } from "react";
import { Input } from "../ui/input";
import { useGetConversationsQuery, Conversation } from "@/store/apis/chat.api";
import { Skeleton } from "@/components/ui/skeleton";
import { timeAgo } from "@/lib/utils";

function Messages() {
  const [userId, setUserId] = useState<string | null>(null);

  useEffect(() => {
    const storedUserId = localStorage.getItem("userId") ;
    setUserId(storedUserId);
  }, []);

  const { data: conversations, isLoading, isError } = useGetConversationsQuery(userId!, {
    skip: !userId,
  });

  const getOtherParticipant = (participants: any[]) => {
    return participants.find(p => p.userId !== userId);
  }

  return (
    <div className="main-card flex items-start justify-start flex-col gap-2">
      <div className="flex items-center justify-between w-full">
        <h2 className="text-xl font-semibold">Messages</h2>
        <Image src="/images/pen.png" width={24} height={24} alt="arrow-right" />
      </div>
      <div className="h-10 mt-4 flex items-center justify-between w-full bg-main-bg px-2 py-3 rounded-full">
        <div className="flex items-center justify-start gap-2">
          <Image
            src="/images/search.png"
            width={24}
            height={24}
            className="size-6"
            alt="search-right"
          />
          <Input
            placeholder="Search"
            className="w-full bg-transparent border-0 shadow-none "
          />
        </div>
        <Image
          src="/images/sort.png"
          width={24}
          height={24}
          alt="sort"
          className="size-6"
        />
      </div>
      <div className="w-full mt-2">
        {isLoading && Array.from({ length: 5 }).map((_, index) => <MessageSkeleton key={index} />)}
        {isError && <div className="text-red-500 text-center p-4">Failed to load conversations.</div>}
        {conversations && conversations.length === 0 && (
            <div className="text-center p-4 text-gray-500">No messages yet.</div>
        )}
        {conversations && conversations.map((convo: Conversation) => {
            const otherUser = getOtherParticipant(convo.participants);
            if (!otherUser) return null;

            return (
                <Message
                    key={convo.id}
                    profile_image={otherUser.profileImage || "/images/user-placeholder.png"}
                    name={otherUser.name}
                    text={convo.lastMessage.content}
                    time={timeAgo(convo.lastMessage.createdAt)}
                    unreadCount={convo.unreadCount}
                />
            )
        })}
      </div>
    </div>
  );
}

export default Messages;

interface MessageProps {
  profile_image: string;
  name: string;
  text: string;
  time: string;
  unreadCount: number;
}

function Message(props: Readonly<MessageProps>) {
  const { profile_image, name, text, time, unreadCount } = props;

  return (
    <div className="p-2 rounded-lg cursor-pointer w-full h-12 flex items-center justify-start gap-1 mb-2 hover:bg-main-bg">
      <Image
        src={profile_image}
        alt="logo"
        width={40}
        className="size-10 rounded-full object-cover"
        height={40}
      />
      <div className="flex-1 flex flex-col items-start justify-start w-full">
        <div className="flex items-center justify-between w-full ">
          <h4 className="capitalize text-base font-semibold ">{name}</h4>
          <p className="text-xs">{time}</p>
        </div>
        <div className="flex items-center justify-between w-full">
          <p className="text-xs truncate">{text}</p>
          {unreadCount > 0 && (
            <p className="text-xs size-4 bg-primary text-white rounded-full text-center flex items-center justify-center">
              {unreadCount}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}

function MessageSkeleton() {
    return (
        <div className="p-2 rounded-lg w-full h-12 flex items-center justify-start gap-1 mb-2">
            <Skeleton className="size-10 rounded-full" />
            <div className="flex-1 flex flex-col items-start justify-start w-full space-y-2">
                <div className="flex items-center justify-between w-full">
                    <Skeleton className="h-4 w-24" />
                    <Skeleton className="h-3 w-16" />
                </div>
                <div className="flex items-center justify-between w-full">
                    <Skeleton className="h-3 w-40" />
                    <Skeleton className="size-4 rounded-full" />
                </div>
            </div>
        </div>
    );
}
